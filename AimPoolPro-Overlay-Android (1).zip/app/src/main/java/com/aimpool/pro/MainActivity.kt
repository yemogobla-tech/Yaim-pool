package com.aimpool.pro

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.aimpool.pro.databinding.ActivityMainBinding

/**
 * Interface de contrôle principale de l'application Aim Pool Pro Overlay.
 * Permet de :
 * - Vérifier et accorder la permission de superposition d'écran
 * - Initialiser MediaProjection pour l'auto-détection optionnelle
 * - Démarrer et arrêter le service d'overlay
 * - Configurer la calibration des dimensions de la table
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isOverlayRunning = false

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkOverlayPermission()
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startOverlayService()
        } else {
            Toast.makeText(this, "Capture d'écran refusée. Mode manuel activé.", Toast.LENGTH_SHORT).show()
            startOverlayService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        updateUiState()
    }

    override fun onResume() {
        super.onResume()
        checkOverlayPermission()
    }

    private fun setupListeners() {
        binding.btnGrantPermission.setOnClickListener {
            requestOverlayPermission()
        }

        binding.btnToggleOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
                return@setOnClickListener
            }

            if (isOverlayRunning) {
                stopOverlayService()
            } else {
                requestMediaProjectionAndStart()
            }
        }

        binding.btnSaveSettings.setOnClickListener {
            val radius = binding.sliderBallRadius.value
            val currentCalib = TableCalibrationManager.loadCalibration(this)
            TableCalibrationManager.saveCalibration(
                this,
                currentCalib.copy(ballRadius = radius)
            )
            Toast.makeText(this, "Paramètres sauvegardés (Rayon: ${radius.toInt()}px)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkOverlayPermission(): Boolean {
        val hasPermission = Settings.canDrawOverlays(this)
        if (hasPermission) {
            binding.txtPermissionStatus.text = "Permission Accordée"
            binding.txtPermissionStatus.setTextColor(getColor(R.color.gold_accent))
            binding.btnGrantPermission.isEnabled = false
            binding.btnGrantPermission.alpha = 0.5f
        } else {
            binding.txtPermissionStatus.text = "Permission Requise (Superposition)"
            binding.txtPermissionStatus.setTextColor(getColor(R.color.error_red))
            binding.btnGrantPermission.isEnabled = true
            binding.btnGrantPermission.alpha = 1.0f
        }
        return hasPermission
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestMediaProjectionAndStart() {
        val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun startOverlayService() {
        AimOverlayService.startService(this)
        isOverlayRunning = true
        updateUiState()
        Toast.makeText(this, "Aim Pool Pro Overlay Démarré !", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlayService() {
        AimOverlayService.stopService(this)
        isOverlayRunning = false
        updateUiState()
        Toast.makeText(this, "Aim Pool Pro Overlay Arrêté", Toast.LENGTH_SHORT).show()
    }

    private fun updateUiState() {
        if (isOverlayRunning) {
            binding.btnToggleOverlay.text = "ARRÊTER L'OVERLAY AIM POOL"
            binding.btnToggleOverlay.setBackgroundColor(getColor(R.color.dark_surface))
            binding.btnToggleOverlay.setTextColor(getColor(R.color.error_red))
            binding.txtServiceStatus.text = "STATUT : SERVICE EN COURS (PASS-THROUGH ACTIF)"
            binding.txtServiceStatus.setTextColor(getColor(R.color.emerald_green))
        } else {
            binding.btnToggleOverlay.text = "DÉMARRER L'OVERLAY AIM POOL PRO"
            binding.btnToggleOverlay.setBackgroundColor(getColor(R.color.gold_accent))
            binding.btnToggleOverlay.setTextColor(getColor(R.color.dark_bg))
            binding.txtServiceStatus.text = "STATUT : PRÊT À DÉMARRER"
            binding.txtServiceStatus.setTextColor(getColor(R.color.text_muted))
        }
    }
}
